import random

# Drei Listen mit synchronen Einträgen
laender = ["Japan", "Italien", "Kanada", "Brasilien", "Norwegen", "Indien"]
staedte = ["Tokio", "Rom", "Toronto", "Rio", "Oslo", "Calicut"]
aktivitaten = ["Street Food essen", "Museen besuchen", "Wandern", "Schwimmen", "Skifahren", "Biriyani Essen"]

print("Willkommen beim realistischen Zufalls-Reiseplaner!")
print("Hier bekommst du geografisch sinnvolle Reiseideen!\n")

for runde in range(5):
    input("Drücke Enter für eine neue Reiseidee...")

    index = random.randint(0, len(laender) - 1)

    land = laender[index]
    stadt = staedte[index]
    aktivitat = aktivitaten[index]

    print(f"Deine nächste Reise geht nach {stadt}, {land} – Du wirst {aktivitat}!\n")

print("Danke für die Nutzung des Zufallsreiseplaners!")
