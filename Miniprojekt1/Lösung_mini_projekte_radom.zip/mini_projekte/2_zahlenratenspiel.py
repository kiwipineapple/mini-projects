import random

zufallszahl = random.randint(1, 100)
versuche = 0
max_versuche = 7

print("Willkommen zum Zahlenratespiel!")
print("Ich denke an eine Zahl zwischen 1 und 100.")
print("Du hast 7 Versuche – viel Erfolg!")

while versuche < max_versuche:
    eingabe = input(f"Versuch {versuche + 1}: Deine Vermutung? ")

    if eingabe.strip().isdigit():               # .strip() entfernt alle Leerzeichen vor und nach dem Text

        tipp = int(eingabe)

        if 1 <= tipp <= 100:
            versuche += 1
            if tipp < zufallszahl:
                print("Zu niedrig! Versuch es mit einer größeren Zahl.")
            elif tipp > zufallszahl:
                print("Zu hoch! Versuch es mit einer kleineren Zahl.")
            else:
                print(f"Richtig! Du hast die Zahl nach {versuche} Versuch(en) erraten.")
                break
        else:
            print("Bitte gib eine ganze Zahl von 1 bis 100 ein.")
    else:
        print("Ungültige Eingabe. Bitte gib nur ganze Zahlen zwischen 1 und 100 ein.")
else:
    print(f"Leider nicht geschafft. Die gesuchte Zahl war: {zufallszahl}")
