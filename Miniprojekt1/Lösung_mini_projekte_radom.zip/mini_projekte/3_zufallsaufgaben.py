import random
import math

print("Willkommen zum Mathe-Quiz!")
print("Du bekommst 10 verschiedene Aufgaben aus Mathe und Zufallsfunktionen.")

punkte = 0

for nummer in range(1, 11):
    print(f"\nAufgabe {nummer}:")

    aufgabentyp = random.choice(["+", "-", "*", "/", "sqrt", "pow", "floor", "ceil", "fabs"])
    richtige_antwort = None

    if aufgabentyp in ["+", "-", "*", "/"]:
        a = random.randint(1, 20)
        b = random.randint(1, 20)
        if aufgabentyp == "+":
            richtige_antwort = a + b
            print(f"Was ist {a} + {b}?")
        elif aufgabentyp == "-":
            richtige_antwort = a - b
            print(f"Was ist {a} - {b}?")
        elif aufgabentyp == "*":
            richtige_antwort = a * b
            print(f"Was ist {a} * {b}?")
        elif aufgabentyp == "/":
            b = random.randint(1, 10)
            richtige_antwort = round(a / b)
            print(f"Was ist {a} / {b} (gerundet auf eine ganze Zahl - .5 wird zur nächsten geraden Zahl gerundet) ?")

    elif aufgabentyp == "sqrt":
        zahl = random.randint(1, 100)
        richtige_antwort = round(math.sqrt(zahl))
        print(f"Was ist die Quadratwurzel von {zahl} (gerundet)?")

    elif aufgabentyp == "pow":
        basis = random.randint(2, 5)
        exponent = random.randint(2, 4)
        richtige_antwort = int(math.pow(basis, exponent))
        print(f"Was ist {basis} hoch {exponent}?")

    elif aufgabentyp == "floor":
        x = random.uniform(1.5, 20.5)
        richtige_antwort = math.floor(x)
        print(f"Was ist der abgerundete Wert von {x:.2f}?")

    elif aufgabentyp == "ceil":
        x = random.uniform(1.5, 20.5)
        richtige_antwort = math.ceil(x)
        print(f"Was ist der aufgerundete Wert von {x:.2f}?")

    elif aufgabentyp == "fabs":
        x = random.randint(-100, 100)
        richtige_antwort = int(math.fabs(x))
        print(f"Was ist der Betrag (Absolute Value) von {x}?")

    eingabe = input("Deine Antwort: ").strip()

    if eingabe.lstrip("-").isdigit():
        user_input = int(eingabe)
        if user_input == richtige_antwort:
            print("Richtig!")
            punkte += 1
        else:
            print(f"Leider falsch. Die richtige Antwort war: {richtige_antwort}")
    else:
        print("Ungültige Eingabe. Diese Aufgabe wird übersprungen.")

# Ergebnis
print(f"Du hast {punkte} von 10 Punkten erreicht!")
if punkte == 10:
    print("Perfekt! Du bist ein Mathe-Profi!")
elif punkte >= 6:
    print("Gut gemacht!")
else:
    print("Weiter üben – du schaffst das!")
